
import React from 'react'
import './App.css';
import Navbar from "./Components/Navbar"
import Herosection from "./Components/Herosection"
import Featuresection from "./Components/Featuresection"
import Cardsection from "./Components/Cardsection"
import Footersection from "./Components/Footersection"

function App() {
  return (
    <div>
      <Navbar/>
      <Featuresection/>
      <Herosection/>
      <Cardsection/>
      <Footersection/>
    </div>
    
  )
}

export default App;
