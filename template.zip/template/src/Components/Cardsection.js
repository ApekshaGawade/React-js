import React from 'react'
import Card from './Card'

const Cardsection=()=>{
    return(
    <section className="contact bg-success ">
    <div className="container ">
      <h2 className="text-white">
        We love new friends!
      </h2>
      <div className="row">
          <Card cardtitle="Orange" cardDescription="There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable." buttontext="Grapes" cardimage="https://4.imimg.com/data4/XC/RA/MY-12203761/orange-flavour-500x500.jpg"/>
          <Card cardtitle="Mango" cardDescription="There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable." buttontext="Jamun" cardimage="https://4.imimg.com/data4/UH/AA/IMOB-40183146/fb_img_1489917102863-500x500.jpg"/>
          <Card cardtitle="Apple" cardDescription="There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable." buttontext="Pear" cardimage="https://5.imimg.com/data5/AK/RA/MY-68428614/apple-500x500.jpg"/>
      </div>
    </div>
  </section>
    )
}
export default Cardsection