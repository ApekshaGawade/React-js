import {useState} from 'react';
import {useEffect} from 'react'

function Main()
{
    
    const [articles,setArticles] = useState([]);
    const [search,setSearch] = useState("microsoft");

    // useEffect(()=>{
    //     let url="https://newsapi.org/v2/everything?q=microsoft&apiKey=73a4c22f93e54b2d8c8bee53e0072e92"
    //     fetch(url)
    //     .then((response)=>response.json())
    //     .then((news)=>{
    //         setArticles(news.articles);
    //     })
    
    // },[])

    function readValue(value)
    {
        setSearch(value);
    }
    function searchNews()
    {
        let url=`https://newsapi.org/v2/everything?q=${search}&apiKey=73a4c22f93e54b2d8c8bee53e0072e92`
        
        fetch(url)
        .then((response)=>response.json())
        .then((news)=>{
            setArticles(news.articles);
        })
    }

    useEffect(()=>{    
        let url=`https://newsapi.org/v2/everything?q=${search}&apiKey=73a4c22f93e54b2d8c8bee53e0072e92`
        
        fetch(url)
        .then((response)=>response.json())
        .then((news)=>{
            setArticles(news.articles);
        })
    
    },[search])

    
    return(
        <div className="container">
            <div className="padd">
                <div className="filter">
                    <input type="search" onChange={(event)=>readValue(event.target.value)} placeholder="Enter the topic to search"/>
                    <button className="btn" onClick={searchNews}>Search for News</button>
                </div>
                <h1>All News</h1>
                {

                    articles.length==0?(<h2>No Data Found</h2>):
                    articles.map((article,index)=>(
                        <div key={index} className="article">
                            <div className="padd-article">
                                <div className="news-img">
                                    <img src={article.urlToImage}>

                                    </img>
                                </div>
                                <div className="news-detail">
                                    <h2>{article.title}</h2>
                                    <p>{article.author}</p>
                                    <p>{article.description}</p>
                                    <p>
                                        <a href={article.url} target="blank">
                                            <button className="btn">Read Full Article...</button>
                                        </a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    ))
                }
            </div>
        </div>
    );
}
export default Main